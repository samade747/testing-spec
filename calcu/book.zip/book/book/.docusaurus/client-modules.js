export default [
  require("D:\\github\\testing-spec\\calcu\\book\\book\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("D:\\github\\testing-spec\\calcu\\book\\book\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("D:\\github\\testing-spec\\calcu\\book\\book\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("D:\\github\\testing-spec\\calcu\\book\\book\\src\\css\\custom.css"),
];
